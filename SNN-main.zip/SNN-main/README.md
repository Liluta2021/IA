# SNN

Hi every one. Usually I'm not a big fan of neural networks, but some of the architectures really espires me. So was with the SNN or Siamese neural network.

In this project are 2 files:
* TRAIN SNN.ipybn - In this jupyter notebook are show the dataset class, the datalaoder, and the train proccess.
* test.py - the implementation of the obtained neural network.

Also here is a folder wiht some of my photo and random photos, use yours instead of mine.

The version of the pytorch used is - 1.6.0.
